"""قراءة الإعدادات من config.json مع إمكانية التجاوز بمتغيرات البيئة.

الأولوية: متغيرات البيئة  >  config.json  >  القيم الافتراضية
متغيرات البيئة المدعومة: GOOGLE_CLIENT_ID ، GOOGLE_CLIENT_SECRET
"""
from __future__ import annotations

import json
import os
from typing import Optional

CONFIG_PATH = os.path.join(os.path.dirname(os.path.abspath(__file__)), "config.json")

DEFAULTS = {
    "client_id": "",
    "client_secret": "",
    "allow_guest": True,          # السماح بالدخول كزائر (للتجربة بدون Google)
    "login_timeout_seconds": 180,  # مهلة انتظار إتمام الدخول في المتصفح
}


def load_settings(path: str = CONFIG_PATH) -> dict:
    data = dict(DEFAULTS)
    data["_load_error"] = ""
    if os.path.exists(path):
        try:
            with open(path, "r", encoding="utf-8") as fh:
                loaded = json.load(fh)
            if isinstance(loaded, dict):
                data.update({k: v for k, v in loaded.items() if not k.startswith("_")})
        except (OSError, ValueError) as exc:
            data["_load_error"] = f"تعذّرت قراءة config.json: {exc}"

    env_id = os.environ.get("GOOGLE_CLIENT_ID")
    env_secret = os.environ.get("GOOGLE_CLIENT_SECRET")
    if env_id:
        data["client_id"] = env_id.strip()
    if env_secret:
        data["client_secret"] = env_secret.strip()
    data["client_id"] = str(data.get("client_id", "")).strip()
    data["client_secret"] = str(data.get("client_secret", "")).strip()
    return data


def validate_for_login(settings: dict) -> Optional[str]:
    """يعيد نص الخطأ إن كانت الإعدادات ناقصة، أو None إن كانت صالحة."""
    if settings.get("_load_error"):
        return settings["_load_error"]
    cid = settings.get("client_id", "")
    if not cid or cid.startswith("YOUR_"):
        return ("لم يتم ضبط Client ID.\n"
                "ضعه في config.json أو في متغير البيئة GOOGLE_CLIENT_ID "
                "(راجع README.md).")
    if not cid.endswith(".apps.googleusercontent.com"):
        return "قيمة client_id غير صحيحة؛ يجب أن تنتهي بـ .apps.googleusercontent.com"
    return None
