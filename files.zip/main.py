"""نقطة التشغيل:  python main.py"""
import sys


def main() -> None:
    if sys.version_info < (3, 8):
        sys.exit("يتطلب هذا التطبيق Python 3.8 أو أحدث.")
    try:
        from ui import App
    except ModuleNotFoundError as exc:
        if exc.name in ("tkinter", "_tkinter"):
            sys.exit("مكتبة tkinter غير مثبتة.\n"
                     "  • Ubuntu/Debian: sudo apt install python3-tk\n"
                     "  • Fedora: sudo dnf install python3-tkinter\n"
                     "  • Windows/macOS: أعد تثبيت Python من python.org مع خيار tcl/tk.")
        raise
    App().mainloop()


if __name__ == "__main__":
    main()
