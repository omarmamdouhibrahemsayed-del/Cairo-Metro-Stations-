"""واجهة tkinter الكاملة: شاشة الدخول + شاشة محطات المترو."""
from __future__ import annotations

import queue
import threading
import tkinter as tk
from tkinter import font as tkfont
from tkinter import messagebox, ttk
from typing import Optional

import auth
import settings as cfg
import stations_data as sd

APP_TITLE = "مترو أنفاق مصر"
FONT_CANDIDATES = ("Segoe UI", "Tahoma", "Noto Sans Arabic", "Noto Naskh Arabic",
                   "DejaVu Sans", "Arial", "Helvetica")
ALL_LINES = "جميع الخطوط"


def _pick_font_family(root: tk.Misc) -> str:
    available = set(tkfont.families(root))
    for name in FONT_CANDIDATES:
        if name in available:
            return name
    return tkfont.nametofont("TkDefaultFont").actual("family")


# ═════════════════════════════ شاشة الدخول ═════════════════════════════
class LoginView(ttk.Frame):
    def __init__(self, master: tk.Misc, app: "App") -> None:
        super().__init__(master)
        self.app = app
        self._login_url = ""

        box = ttk.Frame(self)
        box.place(relx=0.5, rely=0.5, anchor="center")

        ttk.Label(box, text="🚇", font=(app.font_family, 54)).pack(pady=(0, 4))
        ttk.Label(box, text=APP_TITLE, style="Title.TLabel").pack()
        ttk.Label(box, text="جميع محطات الخطوط التشغيلية: الأول والثاني والثالث",
                  style="Sub.TLabel").pack(pady=(4, 24))

        self.btn_login = ttk.Button(box, text="تسجيل الدخول بحساب Google",
                                    style="Accent.TButton", command=app.start_login)
        self.btn_login.pack(ipadx=18, ipady=8, fill="x")

        self.btn_guest = ttk.Button(box, text="المتابعة كزائر (بدون تسجيل)",
                                    command=app.continue_as_guest)
        if app.settings.get("allow_guest", True):
            self.btn_guest.pack(pady=(10, 0), fill="x")

        self.progress = ttk.Progressbar(box, mode="indeterminate", length=280)
        self.lbl_status = ttk.Label(box, text="", style="Sub.TLabel",
                                    wraplength=360, justify="center")
        self.lbl_status.pack(pady=(18, 4))

        self.btn_copy = ttk.Button(box, text="نسخ رابط الدخول", command=self._copy_url)
        self.btn_cancel = ttk.Button(box, text="إلغاء", command=app.cancel_login)

    # --- حالات العرض ---
    def set_busy(self, busy: bool, text: str = "") -> None:
        self.lbl_status.configure(text=text)
        if busy:
            self.btn_login.state(["disabled"])
            self.btn_guest.state(["disabled"])
            self.progress.pack(pady=(4, 8))
            self.progress.start(12)
            self.btn_cancel.pack(pady=(4, 0))
        else:
            self.progress.stop()
            self.progress.pack_forget()
            self.btn_cancel.pack_forget()
            self.btn_copy.pack_forget()
            self.btn_login.state(["!disabled"])
            self.btn_guest.state(["!disabled"])

    def set_status(self, text: str) -> None:
        self.lbl_status.configure(text=text)

    def show_copy(self, url: str) -> None:
        self._login_url = url
        self.btn_copy.pack(pady=(6, 0))

    def _copy_url(self) -> None:
        self.clipboard_clear()
        self.clipboard_append(self._login_url)
        self.set_status("تم نسخ الرابط؛ الصقه في المتصفح.")


# ═════════════════════════════ شاشة المحطات ═════════════════════════════
class MainView(ttk.Frame):
    def __init__(self, master: tk.Misc, app: "App") -> None:
        super().__init__(master)
        self.app = app
        self.search_var = tk.StringVar()
        self.interchange_var = tk.BooleanVar(value=False)
        self.filter_options = [(ALL_LINES, None)] + [
            (f"{ln['name_ar']} — {ln['route_ar']}", lid) for lid, ln in sd.LINES.items()
        ]

        self._build_header()
        self._build_status_bar()
        self._build_body()
        self.search_var.trace_add("write", lambda *_: self.refresh())
        self.refresh()

    # --- الشريط العلوي: بيانات المستخدم ---
    def _build_header(self) -> None:
        header = ttk.Frame(self, style="Header.TFrame", padding=(14, 10))
        header.pack(fill="x", side="top")

        self.btn_logout = ttk.Button(header, text="تسجيل الخروج", command=self.app.logout)
        self.btn_logout.pack(side="left")

        self.avatar = tk.Canvas(header, width=46, height=46, highlightthickness=0,
                                bg="#ffffff")
        self.avatar.pack(side="right", padx=(10, 0))

        info = ttk.Frame(header, style="Header.TFrame")
        info.pack(side="right")
        self.lbl_name = ttk.Label(info, text="", style="HeaderName.TLabel", anchor="e")
        self.lbl_name.pack(anchor="e")
        self.lbl_email = ttk.Label(info, text="", style="HeaderSub.TLabel", anchor="e")
        self.lbl_email.pack(anchor="e")

    def set_user(self, session: Optional[auth.UserSession]) -> None:
        self.avatar.delete("all")
        if session:
            name, email = session.name, session.email
            badge = "✔ البريد موثّق" if session.email_verified else "البريد غير موثّق"
            email_text = f"{email}   ({badge})"
            letter = (name.strip() or "?")[0].upper()
            color = "#1a73e8"
        else:
            name, email_text, letter, color = "زائر", "لم تسجّل الدخول", "ز", "#757575"
        self.avatar.create_oval(2, 2, 44, 44, fill=color, outline="")
        self.avatar.create_text(23, 23, text=letter, fill="white",
                                font=(self.app.font_family, 18, "bold"))
        self.lbl_name.configure(text=name)
        self.lbl_email.configure(text=email_text)
        self.btn_logout.configure(text="تسجيل الخروج" if session else "العودة لشاشة الدخول")

    # --- شريط الحالة ---
    def _build_status_bar(self) -> None:
        bar = ttk.Frame(self, padding=(14, 6))
        bar.pack(fill="x", side="bottom")
        self.lbl_count = ttk.Label(bar, text="", anchor="e")
        self.lbl_count.pack(side="right")
        self.lbl_total = ttk.Label(
            bar, style="Sub.TLabel",
            text=(f"الإجمالي: {sd.unique_count()} محطة فريدة "
                  f"({sd.total_with_repeats()} باحتساب محطات التبادل لكل خط)"))
        self.lbl_total.pack(side="left")

    # --- الجزء الرئيسي ---
    def _build_body(self) -> None:
        paned = ttk.PanedWindow(self, orient="horizontal")
        paned.pack(fill="both", expand=True, padx=10, pady=(8, 0))

        # التفاصيل على اليسار، والقائمة على اليمين (اتجاه عربي)
        details_frame = ttk.Frame(paned, padding=(0, 0, 8, 0))
        list_frame = ttk.Frame(paned)
        paned.add(details_frame, weight=2)
        paned.add(list_frame, weight=3)

        # ---- القائمة وأدوات البحث ----
        tools = ttk.Frame(list_frame)
        tools.pack(fill="x", pady=(0, 8))

        row1 = ttk.Frame(tools)
        row1.pack(fill="x")
        ttk.Label(row1, text="بحث:").pack(side="right", padx=(6, 0))
        self.entry = ttk.Entry(row1, textvariable=self.search_var, justify="right")
        self.entry.pack(side="right", fill="x", expand=True)
        ttk.Button(row1, text="✕", width=3,
                   command=lambda: self.search_var.set("")).pack(side="left", padx=(6, 0))

        row2 = ttk.Frame(tools)
        row2.pack(fill="x", pady=(8, 0))
        ttk.Label(row2, text="الخط:").pack(side="right", padx=(6, 0))
        self.line_combo = ttk.Combobox(row2, state="readonly", justify="right",
                                       values=[t for t, _ in self.filter_options])
        self.line_combo.current(0)
        self.line_combo.pack(side="right", fill="x", expand=True)
        self.line_combo.bind("<<ComboboxSelected>>", lambda _e: self.refresh())
        ttk.Checkbutton(row2, text="محطات التبادل فقط", variable=self.interchange_var,
                        command=self.refresh).pack(side="left", padx=(8, 0))

        columns = ("no", "ar", "en", "lines", "x")
        self.tree = ttk.Treeview(list_frame, columns=columns, show="headings",
                                 displaycolumns=("x", "lines", "en", "ar", "no"),
                                 selectmode="browse")
        for col, title, width, anchor in (
                ("no", "#", 46, "center"),
                ("ar", "المحطة", 170, "e"),
                ("en", "Station", 170, "w"),
                ("lines", "الخط", 120, "center"),
                ("x", "تبادل", 56, "center")):
            self.tree.heading(col, text=title)
            self.tree.column(col, width=width, anchor=anchor, stretch=(col in ("ar", "en")))
        for lid, ln in sd.LINES.items():
            self.tree.tag_configure(f"line{lid}", background=ln["light"])

        scroll = ttk.Scrollbar(list_frame, orient="vertical", command=self.tree.yview)
        self.tree.configure(yscrollcommand=scroll.set)
        scroll.pack(side="left", fill="y")
        self.tree.pack(side="right", fill="both", expand=True)
        self.tree.bind("<<TreeviewSelect>>", self._on_select)

        # ---- لوحة التفاصيل ----
        ttk.Label(details_frame, text="تفاصيل المحطة", style="Head.TLabel",
                  anchor="e").pack(fill="x", pady=(0, 6))
        self.details = tk.Text(details_frame, wrap="word", relief="flat", padx=12, pady=10,
                               font=(self.app.font_family, 11), bg="#ffffff",
                               highlightthickness=1, highlightbackground="#d0d7de",
                               cursor="arrow")
        self.details.pack(fill="both", expand=True)
        self._configure_text_tags()
        self._show_placeholder()

    def _configure_text_tags(self) -> None:
        fam = self.app.font_family
        t = self.details
        t.tag_configure("title", font=(fam, 20, "bold"), justify="right", rmargin=4)
        t.tag_configure("en", font=(fam, 12), foreground="#57606a", justify="right")
        t.tag_configure("body", justify="right", spacing1=2, spacing3=2)
        t.tag_configure("label", font=(fam, 11, "bold"), justify="right", spacing1=8)
        t.tag_configure("hint", foreground="#6e7781", justify="center", spacing1=60)
        t.tag_configure("x", foreground="#b26a00", font=(fam, 11, "bold"), justify="right",
                        spacing1=6)
        t.tag_configure("note", foreground="#24292f", justify="right", spacing1=10)
        for lid, ln in sd.LINES.items():
            t.tag_configure(f"line{lid}", foreground=ln["color"], font=(fam, 13, "bold"),
                            justify="right", spacing1=12)

    def _show_placeholder(self) -> None:
        self.details.configure(state="normal")
        self.details.delete("1.0", "end")
        self.details.insert("end", "اختر محطة من القائمة لعرض تفاصيلها", "hint")
        self.details.configure(state="disabled")

    # --- التحديث والتصفية ---
    def refresh(self) -> None:
        line_id = self.filter_options[self.line_combo.current()][1]
        stations = sd.search(self.search_var.get(), line_id, self.interchange_var.get())

        previous = self.tree.selection()
        self.tree.delete(*self.tree.get_children())
        for i, st in enumerate(stations, 1):
            if line_id:
                number = st.placement(line_id).order
                lines_txt = sd.LINES[line_id]["name_ar"]
                tag = f"line{line_id}"
            else:
                number = i
                lines_txt = " + ".join(sd.LINES[l]["name_ar"].replace("الخط ", "")
                                       for l in st.line_ids)
                tag = f"line{st.line_ids[0]}"
            self.tree.insert("", "end", iid=st.key, tags=(tag,),
                             values=(number, st.name_ar, st.name_en, lines_txt,
                                     "⇄" if st.is_interchange else ""))
        self.lbl_count.configure(text=f"عدد النتائج: {len(stations)}")

        if previous and self.tree.exists(previous[0]):
            self.tree.selection_set(previous[0])
        elif not stations:
            self._show_placeholder()

    def _on_select(self, _event=None) -> None:
        sel = self.tree.selection()
        if sel:
            self.show_details(sel[0])

    def show_details(self, key: str) -> None:
        st = sd.STATIONS[key]
        t = self.details
        t.configure(state="normal")
        t.delete("1.0", "end")
        t.insert("end", st.name_ar + "\n", "title")
        t.insert("end", st.name_en + "\n", "en")

        if st.is_interchange:
            names = " و".join(sd.LINES[l]["name_ar"] for l in st.line_ids)
            t.insert("end", f"⇄ محطة تبادل بين: {names}\n", "x")

        for pl in st.placements:
            ln = sd.LINES[pl.line]
            t.insert("end", f"● {ln['name_ar']}\n", f"line{pl.line}")
            t.insert("end", f"{ln['route_ar']}\n", "en")
            t.insert("end", f"ترتيبها في الخط: {pl.order} من {pl.total}\n", "body")
            if len(ln["segments"]) > 1:
                t.insert("end", f"الفرع: {pl.segment_name}\n", "body")
            if pl.prev:
                t.insert("end", "المحطة السابقة: " + "، ".join(pl.prev) + "\n", "body")
            if pl.next:
                t.insert("end", "المحطة التالية: " + "، ".join(pl.next) + "\n", "body")
            if pl.is_terminal:
                t.insert("end", "هذه محطة طرفية (بداية/نهاية مسار).\n", "body")

        if st.note:
            t.insert("end", "ℹ " + st.note + "\n", "note")
        t.configure(state="disabled")


# ═════════════════════════════ التطبيق ═════════════════════════════
class App(tk.Tk):
    def __init__(self) -> None:
        super().__init__()
        self.title(APP_TITLE)
        self.geometry("1100x700")
        self.minsize(900, 560)

        self.settings = cfg.load_settings()      # لا نسمّيه config: الاسم محجوز في tk
        self.session: Optional[auth.UserSession] = None
        self._queue: "queue.Queue[tuple[str, object]]" = queue.Queue()
        self._cancel_event: Optional[threading.Event] = None
        self._auth_running = False

        self.font_family = _pick_font_family(self)
        self._setup_style()

        container = ttk.Frame(self)
        container.pack(fill="both", expand=True)
        self.login_view = LoginView(container, self)
        self.main_view = MainView(container, self)
        self.show_login()

        self.protocol("WM_DELETE_WINDOW", self._on_close)

    # --- الأنماط ---
    def _setup_style(self) -> None:
        fam = self.font_family
        style = ttk.Style(self)
        if "clam" in style.theme_names():
            style.theme_use("clam")

        # إصلاح معروف: ألوان صفوف Treeview لا تظهر في بعض إصدارات Tk
        def fixed_map(option):
            return [e for e in style.map("Treeview", query_opt=option)
                    if e[:2] != ("!disabled", "!selected")]
        style.map("Treeview", foreground=fixed_map("foreground"),
                  background=fixed_map("background"))

        base = (fam, 11)
        style.configure(".", font=base)
        style.configure("Treeview", font=base, rowheight=30)
        style.configure("Treeview.Heading", font=(fam, 11, "bold"))
        style.configure("Title.TLabel", font=(fam, 28, "bold"))
        style.configure("Sub.TLabel", font=(fam, 11), foreground="#57606a")
        style.configure("Head.TLabel", font=(fam, 14, "bold"))
        style.configure("Header.TFrame", background="#ffffff")
        style.configure("HeaderName.TLabel", background="#ffffff", font=(fam, 13, "bold"))
        style.configure("HeaderSub.TLabel", background="#ffffff", foreground="#57606a")
        style.configure("Accent.TButton", font=(fam, 12, "bold"), foreground="#ffffff",
                        background="#1a73e8")
        style.map("Accent.TButton", background=[("active", "#1765cc"),
                                                ("disabled", "#a8c7fa")])

    # --- التنقل بين الشاشتين ---
    def show_login(self) -> None:
        self.main_view.pack_forget()
        self.login_view.pack(fill="both", expand=True)
        self.login_view.set_busy(False, "")

    def show_main(self) -> None:
        self.login_view.pack_forget()
        self.main_view.set_user(self.session)
        self.main_view.pack(fill="both", expand=True)

    def continue_as_guest(self) -> None:
        self.session = None
        self.show_main()

    # --- تسجيل الدخول (في خيط خلفي كي لا تتجمد الواجهة) ---
    def start_login(self) -> None:
        problem = cfg.validate_for_login(self.settings)
        if problem:
            messagebox.showerror("إعدادات Google ناقصة", problem, parent=self)
            return
        self._cancel_event = threading.Event()
        self._auth_running = True
        self.login_view.set_busy(True, "جارٍ التحضير...")
        threading.Thread(target=self._auth_worker, args=(self._cancel_event,),
                         daemon=True).start()
        self.after(150, self._poll_auth)

    def _auth_worker(self, cancel_event: threading.Event) -> None:
        q = self._queue
        try:
            session = auth.sign_in(self.settings, cancel_event=cancel_event,
                                   on_status=lambda m: q.put(("status", m)),
                                   on_url=lambda u: q.put(("url", u)))
            q.put(("ok", session))
        except auth.AuthCancelled:
            q.put(("cancel", None))
        except auth.AuthError as exc:
            q.put(("error", str(exc)))
        except Exception as exc:                     # noqa: BLE001
            q.put(("error", f"خطأ غير متوقع: {exc}"))

    def _poll_auth(self) -> None:
        try:
            while True:
                kind, payload = self._queue.get_nowait()
                if kind == "status":
                    self.login_view.set_status(str(payload))
                elif kind == "url":
                    self.login_view.show_copy(str(payload))
                elif kind == "ok":
                    self._auth_running = False
                    self.session = payload            # type: ignore[assignment]
                    self.show_main()
                elif kind == "cancel":
                    self._auth_running = False
                    self.login_view.set_busy(False, "تم إلغاء تسجيل الدخول.")
                elif kind == "error":
                    self._auth_running = False
                    self.login_view.set_busy(False, "")
                    messagebox.showerror("تعذّر تسجيل الدخول", str(payload), parent=self)
        except queue.Empty:
            pass
        if self._auth_running:
            self.after(150, self._poll_auth)

    def cancel_login(self) -> None:
        if self._cancel_event:
            self._cancel_event.set()
        self.login_view.set_status("جارٍ الإلغاء...")

    def logout(self) -> None:
        if self.session and self.session.access_token:
            threading.Thread(target=auth.revoke_token,
                             args=(self.session.access_token,), daemon=True).start()
        self.session = None
        self.show_login()

    def _on_close(self) -> None:
        if self._cancel_event:
            self._cancel_event.set()
        self.destroy()
