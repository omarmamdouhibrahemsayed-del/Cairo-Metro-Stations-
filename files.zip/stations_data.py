"""بيانات محطات مترو أنفاق القاهرة الكبرى (الخطوط التشغيلية).

- الخط الأول : حلوان ↔ المرج الجديدة          (35 محطة)
- الخط الثاني: شبرا الخيمة ↔ المنيب            (20 محطة)
- الخط الثالث: عدلي منصور ↔ الكيت كات، ثم فرعان (34 محطة):
      * فرع روض الفرج   (الكيت كات ← محور روض الفرج)
      * فرع جامعة القاهرة (الكيت كات ← جامعة القاهرة)

محطات التبادل تُكتشف تلقائياً: أي محطة يتكرر اسمها العربي في أكثر من خط.
(الأرقام: 89 محطة بالعدّ لكل خط، و84 محطة فريدة بعد حذف تكرار محطات التبادل.)

ملاحظة: الخط الرابع قيد الإنشاء ولذلك غير مُدرج. راجع الموقع الرسمي للهيئة
القومية للأنفاق عند افتتاح محطات جديدة.
"""
from __future__ import annotations

import re
from dataclasses import dataclass, field
from typing import Dict, List, Optional, Tuple


def _parse(block: str) -> List[Tuple[str, str]]:
    """يحوّل نصاً بصيغة «العربي | English» (سطر لكل محطة) إلى قائمة أزواج."""
    out = []
    for raw in block.strip().splitlines():
        raw = raw.strip()
        if raw:
            ar, en = (part.strip() for part in raw.split("|"))
            out.append((ar, en))
    return out


# ───────────────────────────── تعريف الخطوط ─────────────────────────────
LINES: Dict[int, dict] = {
    1: {
        "id": 1,
        "name_ar": "الخط الأول",
        "name_en": "Line 1",
        "route_ar": "حلوان ← المرج الجديدة",
        "color": "#1565c0",
        "light": "#e3f0fc",
        "segments": [
            {
                "name_ar": "المسار الكامل",
                "start": None,
                "stations": _parse("""
                    حلوان | Helwan
                    عين حلوان | Ain Helwan
                    جامعة حلوان | Helwan University
                    وادي حوف | Wadi Hof
                    حدائق حلوان | Hadayek Helwan
                    المعصرة | El-Maasara
                    طرة الأسمنت | Tora El-Asmant
                    كوتسيكا | Kozzika
                    طرة البلد | Tora El-Balad
                    ثكنات المعادي | Sakanat El-Maadi
                    المعادي | Maadi
                    حدائق المعادي | Hadayek El-Maadi
                    دار السلام | Dar El-Salam
                    الزهراء | El-Zahraa
                    مار جرجس | Mar Girgis
                    الملك الصالح | El-Malek El-Saleh
                    السيدة زينب | Al-Sayeda Zeinab
                    سعد زغلول | Saad Zaghloul
                    السادات | Sadat
                    جمال عبد الناصر | Nasser
                    أحمد عرابي | Orabi
                    الشهداء | Al-Shohadaa
                    غمرة | Ghamra
                    الدمرداش | El-Demerdash
                    منشية الصدر | Manshiet El-Sadr
                    كوبري القبة | Kobri El-Qobba
                    حمامات القبة | Hammamat El-Qobba
                    سراي القبة | Saray El-Qobba
                    حدائق الزيتون | Hadayek El-Zaitoun
                    حلمية الزيتون | Helmeyet El-Zaitoun
                    المطرية | El-Matareyya
                    عين شمس | Ain Shams
                    عزبة النخل | Ezbet El-Nakhl
                    المرج | El-Marg
                    المرج الجديدة | New El-Marg
                """),
            }
        ],
    },
    2: {
        "id": 2,
        "name_ar": "الخط الثاني",
        "name_en": "Line 2",
        "route_ar": "شبرا الخيمة ← المنيب",
        "color": "#c62828",
        "light": "#fdeaea",
        "segments": [
            {
                "name_ar": "المسار الكامل",
                "start": None,
                "stations": _parse("""
                    شبرا الخيمة | Shubra El-Kheima
                    كلية الزراعة | Kolleyyet El-Zeraa
                    المظلات | El-Mazallat
                    الخلفاوي | El-Khalafawy
                    سانت تيريزا | St. Teresa
                    روض الفرج | Rod El-Farag
                    مسرة | Massara
                    الشهداء | Al-Shohadaa
                    العتبة | Attaba
                    محمد نجيب | Mohamed Naguib
                    السادات | Sadat
                    الأوبرا | Opera
                    الدقي | Dokki
                    البحوث | El-Bohoth
                    جامعة القاهرة | Cairo University
                    فيصل | Faisal
                    الجيزة | Giza
                    أم المصريين | Omm El-Misryeen
                    ساقية مكي | Sakiat Mekky
                    المنيب | El-Mounib
                """),
            }
        ],
    },
    3: {
        "id": 3,
        "name_ar": "الخط الثالث",
        "name_en": "Line 3",
        "route_ar": "عدلي منصور ← الكيت كات ← (روض الفرج | جامعة القاهرة)",
        "color": "#2e7d32",
        "light": "#e6f4e7",
        "segments": [
            {
                "name_ar": "المسار الرئيسي (عدلي منصور ← الكيت كات)",
                "start": None,
                "stations": _parse("""
                    عدلي منصور | Adly Mansour
                    الهايكستب | El-Haykestep
                    عمر بن الخطاب | Omar Ibn El-Khattab
                    قباء | Qobaa
                    هشام بركات | Hesham Barakat
                    النزهة | El-Nozha
                    نادي الشمس | Nadi El-Shams
                    ألف مسكن | Alf Maskan
                    ميدان هليوبوليس | Heliopolis Square
                    هارون | Haroun
                    الأهرام | Al-Ahram
                    كلية البنات | Koleyet El-Banat
                    الاستاد | Stadium
                    أرض المعارض | Fair Zone
                    العباسية | Abbassia
                    عبده باشا | Abdou Pasha
                    الجيش | El-Geish
                    باب الشعرية | Bab El-Shaaria
                    العتبة | Attaba
                    جمال عبد الناصر | Nasser
                    ماسبيرو | Maspero
                    صفاء حجازي | Safaa Hegazy
                    الكيت كات | Kit Kat
                """),
            },
            {
                "name_ar": "فرع روض الفرج (من الكيت كات)",
                "start": "الكيت كات",
                "stations": _parse("""
                    السودان | Sudan
                    إمبابة | Imbaba
                    البوهي | El-Bohy
                    القومية العربية | El-Qawmia El-Arabia
                    الطريق الدائري | Ring Road
                    محور روض الفرج | Rod El-Farag Corridor
                """),
            },
            {
                "name_ar": "فرع جامعة القاهرة (من الكيت كات)",
                "start": "الكيت كات",
                "stations": _parse("""
                    التوفيقية | Tawfikia
                    وادي النيل | Wadi El-Nil
                    جامعة الدول العربية | Gamaet El-Dowal El-Arabia
                    بولاق الدكرور | Boulak El-Dakrour
                    جامعة القاهرة | Cairo University
                """),
            },
        ],
    },
}

# معلومات إضافية موثوقة عن بعض المحطات (المفتاح: الاسم العربي).
NOTES: Dict[str, str] = {
    "حلوان": "المحطة الطرفية الجنوبية للخط الأول.",
    "المرج الجديدة": "المحطة الطرفية الشمالية للخط الأول.",
    "السادات": "محطة تبادل بين الخطين الأول والثاني، وتقع في ميدان التحرير.",
    "الشهداء": "محطة تبادل بين الخطين الأول والثاني، وتقع في ميدان رمسيس.",
    "العتبة": "محطة تبادل بين الخطين الثاني والثالث.",
    "جمال عبد الناصر": "محطة تبادل بين الخطين الأول والثالث.",
    "جامعة القاهرة": "محطة تبادل بين الخطين الثاني والثالث، وهي المحطة الطرفية لفرع الخط الثالث.",
    "عدلي منصور": "المحطة المركزية للتبادل مع القطار الكهربائي الخفيف (LRT)، "
                  "وهي المحطة الطرفية الشرقية للخط الثالث.",
    "الكيت كات": "نقطة تفرّع الخط الثالث إلى فرعين: روض الفرج وجامعة القاهرة.",
    "محور روض الفرج": "المحطة الطرفية لفرع روض الفرج في الخط الثالث.",
    "شبرا الخيمة": "المحطة الطرفية الشمالية للخط الثاني.",
    "المنيب": "المحطة الطرفية الجنوبية للخط الثاني.",
    "الجيزة": "وفق خطط الهيئة، ستكون محطة تبادل مع الخط الرابع (قيد الإنشاء).",
}


# ───────────────────────────── نماذج البيانات ─────────────────────────────
@dataclass
class Placement:
    """موضع المحطة داخل خط معيّن."""
    line: int
    segment: int
    segment_name: str
    order: int                      # ترتيب المحطة في الخط (يبدأ من 1)
    total: int = 0                  # عدد محطات الخط
    prev: List[str] = field(default_factory=list)   # مفاتيح المحطات السابقة
    next: List[str] = field(default_factory=list)   # مفاتيح المحطات التالية

    @property
    def is_terminal(self) -> bool:
        return not self.prev or not self.next


@dataclass
class Station:
    key: str                        # الاسم العربي (معرّف فريد)
    name_ar: str
    name_en: str
    placements: List[Placement] = field(default_factory=list)

    @property
    def line_ids(self) -> List[int]:
        return [p.line for p in self.placements]

    @property
    def is_interchange(self) -> bool:
        return len(self.placements) > 1

    def placement(self, line_id: int) -> Optional[Placement]:
        for p in self.placements:
            if p.line == line_id:
                return p
        return None

    @property
    def note(self) -> str:
        return NOTES.get(self.key, "")


# ───────────────────────────── بناء الفهارس ─────────────────────────────
STATIONS: Dict[str, Station] = {}
LINE_ORDER: Dict[int, List[str]] = {}      # مفاتيح محطات كل خط بالترتيب


def _build() -> None:
    for line_id, line in LINES.items():
        order = 0
        LINE_ORDER[line_id] = []
        # تمرير أول: إنشاء المحطات ومواضعها
        for seg_idx, seg in enumerate(line["segments"]):
            names = seg["stations"]
            for i, (ar, en) in enumerate(names):
                order += 1
                st = STATIONS.setdefault(ar, Station(ar, ar, en))
                pl = Placement(line_id, seg_idx, seg["name_ar"], order)
                if i > 0:
                    pl.prev.append(names[i - 1][0])
                elif seg["start"]:
                    pl.prev.append(seg["start"])
                if i < len(names) - 1:
                    pl.next.append(names[i + 1][0])
                st.placements.append(pl)
                LINE_ORDER[line_id].append(ar)
        # تمرير ثانٍ: ربط نقطة التفرّع بأول محطة في كل فرع
        for seg in line["segments"]:
            if seg["start"]:
                hub = STATIONS[seg["start"]].placement(line_id)
                hub.next.append(seg["stations"][0][0])
        for key in LINE_ORDER[line_id]:
            STATIONS[key].placement(line_id).total = order


_build()


# ───────────────────────────── البحث والتصفية ─────────────────────────────
_DIACRITICS = re.compile(r"[\u0610-\u061A\u064B-\u065F\u0670\u06D6-\u06ED\u0640]")
_AR_MAP = str.maketrans({"أ": "ا", "إ": "ا", "آ": "ا", "ى": "ي",
                         "ة": "ه", "ؤ": "و", "ئ": "ي"})
_PUNCT = re.compile(r"[\-_'’.]+")


def normalize(text: str) -> str:
    """توحيد النص للبحث: إزالة التشكيل وتوحيد الهمزات والتاء المربوطة وغيرها."""
    text = _DIACRITICS.sub("", text.strip().lower()).translate(_AR_MAP)
    text = _PUNCT.sub(" ", text)
    return re.sub(r"\s+", " ", text)


def search(query: str = "", line_id: Optional[int] = None,
           interchange_only: bool = False) -> List[Station]:
    """يعيد المحطات المطابقة بدون تكرار، مرتبةً حسب الخط ثم ترتيب المحطة."""
    q = normalize(query)
    lines = [line_id] if line_id else sorted(LINES)
    seen, result = set(), []
    for lid in lines:
        for key in LINE_ORDER[lid]:
            if key in seen:
                continue
            st = STATIONS[key]
            if interchange_only and not st.is_interchange:
                continue
            if q and q not in normalize(st.name_ar) and q not in normalize(st.name_en):
                continue
            seen.add(key)
            result.append(st)
    return result


def line_count(line_id: int) -> int:
    return len(LINE_ORDER[line_id])


def total_with_repeats() -> int:
    return sum(len(v) for v in LINE_ORDER.values())


def unique_count() -> int:
    return len(STATIONS)


def interchanges() -> List[Station]:
    return [s for s in STATIONS.values() if s.is_interchange]
