"""تسجيل الدخول بحساب Google (OAuth 2.0 للتطبيقات المكتبية) بمكتبة بايثون القياسية فقط.

التدفق (Authorization Code + PKCE + loopback redirect):
  1) توليد code_verifier / code_challenge و state عشوائي.
  2) تشغيل خادم http.server محلي مؤقت على 127.0.0.1 بمنفذ عشوائي.
  3) فتح رابط التفويض في المتصفح بواسطة webbrowser.
  4) استقبال ?code=... على /callback والتحقق من state.
  5) تبديل الـ code بـ access_token عبر urllib.request (POST).
  6) جلب الاسم والبريد من userinfo.
"""
from __future__ import annotations

import base64
import hashlib
import hmac
import json
import secrets
import time
import urllib.error
import urllib.parse
import urllib.request
import webbrowser
from dataclasses import dataclass
from http.server import BaseHTTPRequestHandler, ThreadingHTTPServer
from typing import Callable, Optional

AUTH_URL = "https://accounts.google.com/o/oauth2/v2/auth"
TOKEN_URL = "https://oauth2.googleapis.com/token"
USERINFO_URL = "https://openidconnect.googleapis.com/v1/userinfo"
REVOKE_URL = "https://oauth2.googleapis.com/revoke"
SCOPES = "openid email profile"


class AuthError(Exception):
    """خطأ أثناء تسجيل الدخول (الرسالة جاهزة للعرض للمستخدم)."""


class AuthCancelled(AuthError):
    """أُلغيت العملية من المستخدم."""


@dataclass
class UserSession:
    name: str
    email: str
    picture: str
    sub: str
    email_verified: bool
    access_token: str


# ───────────────────────── الخادم المحلي لاستقبال الاستجابة ─────────────────────────
class _CallbackServer(ThreadingHTTPServer):
    daemon_threads = True
    result: Optional[dict] = None


class _CallbackHandler(BaseHTTPRequestHandler):
    server_version = "EgyptMetroAuth/1.0"

    def do_GET(self) -> None:  # noqa: N802 (اسم مفروض من http.server)
        parsed = urllib.parse.urlparse(self.path)
        if parsed.path != "/callback":
            self._reply(404, "Not found")
            return
        query = {k: v[0] for k, v in urllib.parse.parse_qs(parsed.query).items()}
        if "code" not in query and "error" not in query:
            self._reply(400, "طلب غير صالح.")
            return
        if self.server.result is None:           # نقبل أول استجابة فقط
            self.server.result = query
        if "error" in query:
            self._reply(200, "لم تكتمل عملية تسجيل الدخول. يمكنك إغلاق هذه النافذة "
                             "والعودة إلى التطبيق.")
        else:
            self._reply(200, "تم تسجيل الدخول بنجاح ✔\nيمكنك إغلاق هذه النافذة "
                             "والعودة إلى التطبيق.")

    def _reply(self, status: int, text: str) -> None:
        body = text.encode("utf-8")
        self.send_response(status)
        self.send_header("Content-Type", "text/plain; charset=utf-8")
        self.send_header("Content-Length", str(len(body)))
        self.end_headers()
        self.wfile.write(body)

    def log_message(self, *args) -> None:        # إسكات سجل الخادم
        pass


# ───────────────────────── أدوات HTTP ─────────────────────────
def _request_json(req: urllib.request.Request, timeout: int = 20) -> dict:
    try:
        with urllib.request.urlopen(req, timeout=timeout) as resp:
            return json.loads(resp.read().decode("utf-8"))
    except urllib.error.HTTPError as exc:
        body = exc.read().decode("utf-8", "replace")
        try:
            info = json.loads(body)
            detail = info.get("error_description") or info.get("error") or body
        except ValueError:
            detail = body
        raise AuthError(f"رفض Google الطلب (HTTP {exc.code}): {detail}") from exc
    except urllib.error.URLError as exc:
        raise AuthError(f"تعذّر الاتصال بخوادم Google: {exc.reason}") from exc
    except (OSError, ValueError) as exc:
        raise AuthError(f"استجابة غير متوقعة من Google: {exc}") from exc


def _pkce_pair() -> tuple[str, str]:
    verifier = secrets.token_urlsafe(64)         # 86 حرفاً (المسموح 43–128)
    digest = hashlib.sha256(verifier.encode("ascii")).digest()
    challenge = base64.urlsafe_b64encode(digest).rstrip(b"=").decode("ascii")
    return verifier, challenge


def _wait_for_callback(server: _CallbackServer, cancel_event, timeout: float) -> dict:
    server.timeout = 0.5
    deadline = time.monotonic() + timeout
    while time.monotonic() < deadline:
        if cancel_event is not None and cancel_event.is_set():
            raise AuthCancelled("تم إلغاء تسجيل الدخول.")
        server.handle_request()
        if server.result is not None:
            return server.result
    raise AuthError("انتهت مهلة انتظار تسجيل الدخول. حاول مرة أخرى.")


# ───────────────────────── الواجهة العامة ─────────────────────────
def sign_in(settings: dict,
            cancel_event=None,
            on_status: Optional[Callable[[str], None]] = None,
            on_url: Optional[Callable[[str], None]] = None) -> UserSession:
    """ينفّذ تدفق الدخول كاملاً (استدعِه من خيط خلفي كي لا تتجمد الواجهة)."""
    status = on_status or (lambda _m: None)
    client_id = settings["client_id"]
    client_secret = settings.get("client_secret", "")
    timeout = float(settings.get("login_timeout_seconds", 180))

    verifier, challenge = _pkce_pair()
    state = secrets.token_urlsafe(24)

    try:
        server = _CallbackServer(("127.0.0.1", 0), _CallbackHandler)
    except OSError as exc:
        raise AuthError(f"تعذّر تشغيل الخادم المحلي: {exc}") from exc

    try:
        redirect_uri = f"http://127.0.0.1:{server.server_address[1]}/callback"
        params = {
            "client_id": client_id,
            "redirect_uri": redirect_uri,
            "response_type": "code",
            "scope": SCOPES,
            "state": state,
            "code_challenge": challenge,
            "code_challenge_method": "S256",
            "prompt": "select_account",
        }
        url = f"{AUTH_URL}?{urllib.parse.urlencode(params)}"

        if on_url:
            on_url(url)
        status("جارٍ فتح المتصفح... أكمل تسجيل الدخول هناك.")
        if not webbrowser.open(url):
            status("تعذّر فتح المتصفح تلقائياً؛ انسخ رابط الدخول وافتحه يدوياً.")

        result = _wait_for_callback(server, cancel_event, timeout)
    finally:
        server.server_close()

    if "error" in result:
        if result["error"] == "access_denied":
            raise AuthError("ألغيت الدخول أو لم تمنح التطبيق الإذن المطلوب.")
        raise AuthError(f"أعاد Google خطأ: {result['error']}")
    if not hmac.compare_digest(result.get("state", ""), state):
        raise AuthError("فشل التحقق الأمني (state غير مطابق). أعد المحاولة.")

    status("جارٍ تبديل رمز التفويض برمز الدخول...")
    form = {
        "code": result["code"],
        "client_id": client_id,
        "redirect_uri": redirect_uri,
        "grant_type": "authorization_code",
        "code_verifier": verifier,
    }
    if client_secret:                      # Google تطلبه حتى لتطبيقات سطح المكتب
        form["client_secret"] = client_secret
    token_req = urllib.request.Request(
        TOKEN_URL,
        data=urllib.parse.urlencode(form).encode("ascii"),
        headers={"Content-Type": "application/x-www-form-urlencoded"},
        method="POST",
    )
    tokens = _request_json(token_req)
    access_token = tokens.get("access_token")
    if not access_token:
        raise AuthError("لم يُرجع Google رمز دخول صالحاً.")

    status("جارٍ جلب بيانات الحساب...")
    info_req = urllib.request.Request(
        USERINFO_URL, headers={"Authorization": f"Bearer {access_token}"})
    info = _request_json(info_req)

    email = info.get("email", "")
    return UserSession(
        name=info.get("name") or email or "مستخدم Google",
        email=email,
        picture=info.get("picture", ""),
        sub=info.get("sub", ""),
        email_verified=bool(info.get("email_verified", False)),
        access_token=access_token,
    )


def revoke_token(access_token: str) -> None:
    """إلغاء الرمز عند تسجيل الخروج (بأفضل جهد؛ الأخطاء تُتجاهل)."""
    try:
        req = urllib.request.Request(
            REVOKE_URL,
            data=urllib.parse.urlencode({"token": access_token}).encode("ascii"),
            headers={"Content-Type": "application/x-www-form-urlencoded"},
            method="POST",
        )
        urllib.request.urlopen(req, timeout=10).close()
    except Exception:
        pass
